-- Your SQL goes here
CREATE TABLE sessions (
    token TEXT PRIMARY KEY
)
