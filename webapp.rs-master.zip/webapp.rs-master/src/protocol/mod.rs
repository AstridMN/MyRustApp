//! The main protocol handling

pub mod model;
pub mod request;
pub mod response;
